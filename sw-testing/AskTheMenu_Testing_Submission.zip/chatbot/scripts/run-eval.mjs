#!/usr/bin/env node
import { spawnSync } from "node:child_process";
import { writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { performance } from "node:perf_hooks";
import { fileURLToPath } from "node:url";
import dotenv from "dotenv";

/**
 * Evaluates AskTheMenu against a set of test prompts.
 *
 * Usage:
 *   node --conditions react-server --import tsx scripts/run-eval.mjs
 *   node --conditions react-server --import tsx scripts/run-eval.mjs --all
 *   node --conditions react-server --import tsx scripts/run-eval.mjs --category allergen
 *
 * This script calls Gemini for retrieval and Groq for generation, so it uses
 * API quota. Output is written to eval-results.md in the chatbot root.
 */

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const ROOT = resolve(__dirname, "..");

function hasReactServerCondition() {
  return process.execArgv.some((arg, index, args) => {
    if (arg === "--conditions" || arg === "-C") {
      return args[index + 1] === "react-server";
    }

    return (
      arg === "--conditions=react-server" ||
      arg === "--condition=react-server" ||
      arg === "-C=react-server"
    );
  });
}

if (!hasReactServerCondition()) {
  const result = spawnSync(
    process.execPath,
    ["--conditions", "react-server", ...process.execArgv, __filename, ...process.argv.slice(2)],
    {
      env: process.env,
      stdio: "inherit",
    }
  );

  process.exit(result.status ?? 1);
}

dotenv.config({ path: resolve(ROOT, ".env.local") });
process.env.LLM_TRACE ??= "0";

function unwrapModule(mod) {
  return mod.default ?? mod;
}

const evalPromptModule = unwrapModule(await import("./eval-prompts.ts"));
const { evalPrompts, getQuickRunPrompts, getPromptsByCategory } =
  evalPromptModule;

let buildMenuContext;
let systemPrompt;
try {
  const menuSearchModule = unwrapModule(await import("../lib/menu/search.ts"));
  const promptModule = unwrapModule(await import("../lib/ai/prompts.ts"));
  buildMenuContext = menuSearchModule.buildMenuContext;
  systemPrompt = promptModule.systemPrompt;
} catch (error) {
  console.error(
    "Could not import the production retriever. Run with: node --conditions react-server --import tsx scripts/run-eval.mjs"
  );
  throw error;
}

const args = process.argv.slice(2);
const runAll = args.includes("--all");
const categoryIdx = args.indexOf("--category");
const categoryFilter =
  categoryIdx !== -1 && args[categoryIdx + 1] ? args[categoryIdx + 1] : null;

let selectedPrompts;
if (runAll) {
  selectedPrompts = evalPrompts;
  console.log(`Running ALL ${selectedPrompts.length} prompts.\n`);
} else if (categoryFilter) {
  selectedPrompts = getPromptsByCategory(categoryFilter);
  console.log(
    `Running ${selectedPrompts.length} prompts in category "${categoryFilter}".\n`
  );
} else {
  selectedPrompts = getQuickRunPrompts();
  console.log(
    `Quick run: ${selectedPrompts.length} prompts (use --all for all ${evalPrompts.length}).\n`
  );
}

if (selectedPrompts.length === 0) {
  console.error("No prompts selected. Check --category filter.");
  process.exit(1);
}

const GROQ_API_KEY = process.env.GROQ_API_KEY;
const GROQ_BASE_URL =
  process.env.GROQ_BASE_URL ?? "https://api.groq.com/openai/v1";
const MODEL = process.env.GROQ_MODEL ?? "openai/gpt-oss-120b";

if (!GROQ_API_KEY) {
  console.error("GROQ_API_KEY not set in .env.local");
  process.exit(1);
}

const REQUEST_HINTS = {
  latitude: undefined,
  longitude: undefined,
  city: undefined,
  country: undefined,
};

function countRetrievedChunks(menuContext) {
  return menuContext
    .split("\n")
    .filter((line) => line.trim().startsWith("- ")).length;
}

async function callLLM(userPrompt, chatSystemPrompt, retries = 5) {
  for (let attempt = 0; attempt <= retries; attempt++) {
    const response = await fetch(`${GROQ_BASE_URL}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${GROQ_API_KEY}`,
      },
      body: JSON.stringify({
        model: MODEL,
        messages: [
          { role: "system", content: chatSystemPrompt },
          { role: "user", content: userPrompt },
        ],
        temperature: 0.3,
        max_tokens: 300,
      }),
    });

    if (response.status === 429 && attempt < retries) {
      const body = await response.text();
      const waitMatch = body.match(/try again in ([\d.]+)s/);
      const waitSec = waitMatch
        ? Math.ceil(Number.parseFloat(waitMatch[1])) + 5
        : Math.min((attempt + 1) * 30, 120);
      console.log(
        `\n    Rate limited, waiting ${waitSec}s (attempt ${attempt + 1}/${retries})...`
      );
      process.stdout.write("    ");
      await new Promise((resolveDelay) =>
        setTimeout(resolveDelay, waitSec * 1000)
      );
      continue;
    }

    if (!response.ok) {
      const text = await response.text();
      throw new Error(`Groq API error (${response.status}): ${text}`);
    }

    const data = await response.json();
    return data.choices?.[0]?.message?.content ?? "(no response)";
  }

  throw new Error("Max retries exceeded for rate limiting");
}

function checkGuardrails(prompt, response) {
  const issues = [];

  if (prompt.forbiddenPatterns) {
    for (const pattern of prompt.forbiddenPatterns) {
      if (response.toLowerCase().includes(pattern.toLowerCase())) {
        issues.push(`FAIL: forbidden pattern found: "${pattern}"`);
      }
    }
  }

  const wordCount = response.split(/\s+/).length;
  if (wordCount > 300) {
    issues.push(`WARN: response is very long (${wordCount} words)`);
  }

  return issues;
}

const results = [];
let passed = 0;
let warnings = 0;
let failed = 0;

for (const [index, prompt] of selectedPrompts.entries()) {
  process.stdout.write(`  [${prompt.id}] ${prompt.prompt.slice(0, 50)}... `);

  try {
    const retrievalStart = performance.now();
    const menuContext = await buildMenuContext(prompt.prompt);
    const retrievalLatencyMs = Math.round(performance.now() - retrievalStart);
    const retrievedChunks = countRetrievedChunks(menuContext);

    const chatSystemPrompt = systemPrompt({
      requestHints: REQUEST_HINTS,
      supportsTools: false,
      menuContext,
      tableLabel: "eval",
    });

    const t0 = performance.now();
    const response = await callLLM(prompt.prompt, chatSystemPrompt);
    const latencyMs = Math.round(performance.now() - t0);
    const issues = checkGuardrails(prompt, response);

    const status = issues.some((issue) => issue.startsWith("FAIL:"))
      ? "FAIL"
      : issues.length > 0
        ? "WARN"
        : "PASS";

    if (status === "FAIL") {
      failed++;
    } else if (status === "WARN") {
      warnings++;
    } else {
      passed++;
    }

    console.log(`${status} (${latencyMs}ms, ${retrievedChunks} chunks)`);

    results.push({
      ...prompt,
      response,
      issues,
      status,
      latencyMs,
      retrievalLatencyMs,
      retrievedChunks,
      menuContext,
    });
  } catch (err) {
    console.log("ERROR");
    failed++;
    results.push({
      ...prompt,
      response: `ERROR: ${err.message}`,
      issues: [`ERROR: retrieval or API call failed: ${err.message}`],
      status: "ERROR",
      latencyMs: -1,
      retrievalLatencyMs: -1,
      retrievedChunks: 0,
      menuContext: "",
    });
  }

  if (index < selectedPrompts.length - 1) {
    await new Promise((resolveDelay) => setTimeout(resolveDelay, 32_000));
  }
}

const timestamp = new Date().toISOString();
const total = results.length;

let report = `# AskTheMenu Evaluation Report

**Date:** ${timestamp}
**Model:** ${MODEL}
**Prompts tested:** ${total}
**Retriever:** production RAG retriever via buildMenuContext
**Results:** ${passed} passed | ${warnings} warnings | ${failed} failed

---

`;

for (const r of results) {
  report += `## ${r.status} [${r.id}] ${r.category}

**Prompt:** ${r.prompt}

**Expected:** ${r.expectedBehavior}

**Latency:** ${r.latencyMs >= 0 ? `${r.latencyMs} ms` : "N/A"}

**Retrieved chunks:** ${r.retrievedChunks}${
    r.retrievalLatencyMs >= 0 ? ` (${r.retrievalLatencyMs} ms)` : ""
  }

**Response:**
> ${r.response.replace(/\n/g, "\n> ")}

`;

  if (r.issues.length > 0) {
    report += `**Issues:**\n${r.issues.map((issue) => `- ${issue}`).join("\n")}\n`;
  }

  report += "\n---\n\n";
}

const successfulLatencies = results
  .filter((result) => result.latencyMs > 0)
  .map((result) => result.latencyMs);
const avgLatency =
  successfulLatencies.length > 0
    ? Math.round(
        successfulLatencies.reduce((sum, value) => sum + value, 0) /
          successfulLatencies.length
      )
    : 0;
const minLatency =
  successfulLatencies.length > 0 ? Math.min(...successfulLatencies) : 0;
const maxLatency =
  successfulLatencies.length > 0 ? Math.max(...successfulLatencies) : 0;
const medianLatency =
  successfulLatencies.length > 0
    ? [...successfulLatencies].sort((a, b) => a - b)[
        Math.floor(successfulLatencies.length / 2)
      ]
    : 0;

const successfulRetrievals = results.filter(
  (result) => result.retrievalLatencyMs > 0
);
const avgRetrievedChunks =
  successfulRetrievals.length > 0
    ? (
        successfulRetrievals.reduce(
          (sum, result) => sum + result.retrievedChunks,
          0
        ) / successfulRetrievals.length
      ).toFixed(1)
    : "0.0";

report += `## Summary Statistics

| Metric | Value |
|--------|-------|
| Total prompts | ${total} |
| Passed | ${passed} |
| Warnings | ${warnings} |
| Failed | ${failed} |
| Pass rate | ${((passed / total) * 100).toFixed(1)}% |
| Avg retrieved chunks | ${avgRetrievedChunks} |
| Avg latency (successful) | ${avgLatency} ms |
| Min latency | ${minLatency} ms |
| Max latency | ${maxLatency} ms |
| Median latency | ${medianLatency} ms |
`;

const reportPath = resolve(ROOT, "eval-results.md");
writeFileSync(reportPath, report, "utf-8");

console.log(`\nResults: ${passed} passed | ${warnings} warnings | ${failed} failed`);
console.log(
  `Avg latency: ${avgLatency}ms | Min: ${minLatency}ms | Max: ${maxLatency}ms`
);
console.log(`Avg retrieved chunks: ${avgRetrievedChunks}`);
console.log(`Report saved to: ${reportPath}`);
