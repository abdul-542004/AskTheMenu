import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import { restaurantTable } from "@/lib/db/schema";
import { getDatabaseUrl, hasDatabaseUrl, isSupabasePoolerUrl } from "@/lib/db/url";

const FALLBACK_TABLE_SLUGS = new Set([
  "table-1",
  "table-2",
  "table-3",
  "table-4",
  "table-5",
]);

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const slug = searchParams.get("slug");

  if (!slug) {
    return NextResponse.json(
      { valid: false, error: "Missing table slug parameter" },
      { status: 400 }
    );
  }

  // If database is available, validate against the RestaurantTable database table
  if (hasDatabaseUrl()) {
    try {
      const databaseUrl = getDatabaseUrl();
      const isPooler = isSupabasePoolerUrl(databaseUrl);
      const client = postgres(databaseUrl, {
        connect_timeout: 5,
        prepare: !isPooler,
      });
      const db = drizzle(client);

      const [table] = await db
        .select({
          id: restaurantTable.id,
          label: restaurantTable.label,
          isActive: restaurantTable.isActive,
        })
        .from(restaurantTable)
        .where(
          and(
            eq(restaurantTable.qrSlug, slug),
            eq(restaurantTable.isActive, true)
          )
        )
        .limit(1);

      await client.end();

      if (table) {
        return NextResponse.json({
          valid: true,
          label: table.label,
          id: table.id,
        });
      }

      return NextResponse.json(
        { valid: false, error: `Table "${slug}" not found or inactive` },
        { status: 404 }
      );
    } catch (err) {
      console.warn("Table DB validation failed, using fallback tables:", err);
    }
  }

  // Fallback validation for static table list (e.g. table-1 to table-5)
  if (FALLBACK_TABLE_SLUGS.has(slug)) {
    const tableNum = slug.replace("table-", "");
    return NextResponse.json({
      valid: true,
      label: `Table ${tableNum}`,
      id: slug,
    });
  }

  return NextResponse.json(
    { valid: false, error: `Table "${slug}" not found or inactive` },
    { status: 404 }
  );
}
