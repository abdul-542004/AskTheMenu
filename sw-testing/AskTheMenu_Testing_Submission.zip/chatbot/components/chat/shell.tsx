"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import useSWR from "swr";
import { AlertTriangle, QrCode, UtensilsCrossed } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useActiveChat } from "@/hooks/use-active-chat";
import {
  initialArtifactData,
  useArtifact,
  useArtifactSelector,
} from "@/hooks/use-artifact";
import type { Attachment, ChatMessage } from "@/lib/types";
import { ChatHeader } from "./chat-header";
import { DataStreamHandler } from "./data-stream-handler";
import { submitEditedMessage } from "./message-editor";
import { Messages } from "./messages";
import { MultimodalInput } from "./multimodal-input";

export function ChatShell() {
  const {
    chatId,
    tableSlug,
    messages,
    setMessages,
    sendMessage,
    status,
    stop,
    regenerate,
    addToolApprovalResponse,
    input,
    setInput,
    visibilityType,
    isReadonly,
    isLoading,
    votes,
    currentModelId,
    setCurrentModelId,
    showGroqKeyAlert,
    setShowGroqKeyAlert,
  } = useActiveChat();

  const [editingMessage, setEditingMessage] = useState<ChatMessage | null>(
    null
  );
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const isArtifactVisible = useArtifactSelector(() => false);
  const { setArtifact } = useArtifact();

  // Validate table slug on the frontend against the database / system
  const {
    data: _tableValidation,
    error: tableValidationError,
    isLoading: isValidatingTable,
  } = useSWR(
    tableSlug ? `/api/tables/validate?slug=${encodeURIComponent(tableSlug)}` : null,
    async (url: string) => {
      const res = await fetch(url);
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error || "Invalid table");
      }
      return res.json() as Promise<{ valid: boolean; label: string; id: string }>;
    },
    { revalidateOnFocus: false, shouldRetryOnError: false }
  );

  const isInvalidTable = Boolean(tableSlug && tableValidationError);

  const stopRef = useRef(stop);
  stopRef.current = stop;

  const prevChatIdRef = useRef(chatId);
  useEffect(() => {
    if (prevChatIdRef.current !== chatId) {
      prevChatIdRef.current = chatId;
      stopRef.current();
      setArtifact(initialArtifactData);
      setEditingMessage(null);
      setAttachments([]);
    }
  }, [chatId, setArtifact]);

  return (
    <>
      <div className="flex h-dvh w-full flex-row overflow-hidden">
        <div className="flex w-full min-w-0 flex-col bg-sidebar transition-[width] duration-300 ease-[cubic-bezier(0.32,0.72,0,1)]">
          <ChatHeader
            chatId={chatId}
            isReadonly={isReadonly}
            selectedVisibilityType={visibilityType}
            tableSlug={isInvalidTable ? null : tableSlug}
          />

          <div className="relative flex min-h-0 flex-1 flex-col overflow-hidden bg-background md:rounded-tl-[12px] md:border-t md:border-l md:border-border/40">
            {isInvalidTable ? (
              <div
                data-testid="invalid-table-card"
                className="flex flex-1 flex-col items-center justify-center p-6 text-center animate-in fade-in duration-300"
              >
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-destructive/10 text-destructive mb-4 ring-8 ring-destructive/5">
                  <AlertTriangle className="h-8 w-8" />
                </div>
                <h2 className="text-2xl font-bold tracking-tight text-foreground mb-2">
                  Invalid or Inactive Table
                </h2>
                <p className="max-w-md text-sm text-muted-foreground mb-6">
                  Table{" "}
                  <span className="font-semibold text-foreground">
                    &ldquo;{tableSlug}&rdquo;
                  </span>{" "}
                  is not recognized or is currently inactive. Please scan an active table QR code or browse our menu.
                </p>
                <div className="flex flex-wrap items-center justify-center gap-3">
                  <Button asChild variant="default" className="gap-2">
                    <Link href="/menu">
                      <UtensilsCrossed className="h-4 w-4" />
                      Browse Menu
                    </Link>
                  </Button>
                  <Button asChild variant="outline" className="gap-2">
                    <Link href="/qr">
                      <QrCode className="h-4 w-4" />
                      View Table QR Codes
                    </Link>
                  </Button>
                </div>
              </div>
            ) : isValidatingTable && tableSlug ? (
              <div className="flex flex-1 flex-col items-center justify-center p-6 text-center">
                <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent mb-3" />
                <p className="text-sm text-muted-foreground">Verifying table session...</p>
              </div>
            ) : (
              <>
                <Messages
                  addToolApprovalResponse={addToolApprovalResponse}
                  chatId={chatId}
                  isArtifactVisible={isArtifactVisible}
                  isLoading={isLoading}
                  isReadonly={isReadonly}
                  messages={messages}
                  onEditMessage={(msg) => {
                    const text = msg.parts
                      ?.filter((p) => p.type === "text")
                      .map((p) => p.text)
                      .join("");
                    setInput(text ?? "");
                    setEditingMessage(msg);
                  }}
                  regenerate={regenerate}
                  selectedModelId={currentModelId}
                  setMessages={setMessages}
                  status={status}
                  votes={votes}
                />

                <div className="sticky bottom-0 z-1 mx-auto flex w-full max-w-4xl gap-2 border-t-0 bg-background px-2 pb-3 md:px-4 md:pb-4">
                  {!isReadonly && (
                    <MultimodalInput
                      attachments={attachments}
                      chatId={chatId}
                      editingMessage={editingMessage}
                      input={input}
                      isLoading={isLoading}
                      messages={messages}
                      onCancelEdit={() => {
                        setEditingMessage(null);
                        setInput("");
                      }}
                      onModelChange={setCurrentModelId}
                      selectedModelId={currentModelId}
                      selectedVisibilityType={visibilityType}
                      sendMessage={
                        editingMessage
                          ? async () => {
                              const msg = editingMessage;
                              setEditingMessage(null);
                              await submitEditedMessage({
                                message: msg,
                                text: input,
                                setMessages,
                                regenerate,
                              });
                              setInput("");
                            }
                          : sendMessage
                      }
                      setAttachments={setAttachments}
                      setInput={setInput}
                      setMessages={setMessages}
                      status={status}
                      stop={stop}
                      tableSlug={tableSlug}
                    />
                  )}
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      <DataStreamHandler />

      <AlertDialog onOpenChange={setShowGroqKeyAlert} open={showGroqKeyAlert}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Configure Groq</AlertDialogTitle>
            <AlertDialogDescription>
              This application requires{" "}
              {process.env.NODE_ENV === "production" ? "the owner" : "you"} to
              set GROQ_API_KEY before chat requests can be sent.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                window.open("https://console.groq.com/keys", "_blank");
                window.location.href = `${process.env.NEXT_PUBLIC_BASE_PATH ?? ""}/`;
              }}
            >
              Open Keys
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
