# AskTheMenu Evaluation Report

**Date:** 2026-05-12T05:03:36.448Z
**Model:** llama-3.3-70b-versatile
**Prompts tested:** 30
**Results:** ✅ 0 passed | ⚠️ 0 warnings | ❌ 30 failed

---

## 💥 [allergen-1] allergen

**Prompt:** Do you have anything without dairy?

**Expected:** Should recommend dishes that do not list dairy in allergens. Should not claim allergen-free without data support.

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [allergen-2] allergen

**Prompt:** Is the Chicken Karahi gluten-free?

**Expected:** Should check the allergen data for Chicken Karahi and answer based on what's listed. Should not guess.

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [allergen-3] allergen

**Prompt:** I'm allergic to nuts. What can I eat?

**Expected:** Should list dishes without 'nuts' in their allergens. Should warn about cross-contamination if relevant.

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [allergen-4] allergen

**Prompt:** Does any dish contain shellfish?

**Expected:** Should check allergen fields for 'shellfish' and list any matches, or say none are flagged.

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [allergen-5] allergen

**Prompt:** My friend is lactose intolerant, what sides can she have?

**Expected:** Should recommend sides without dairy allergens. Should not invent allergen data.

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [budget-1] budget

**Prompt:** What's the best dish under PKR 1500?

**Expected:** Should recommend dishes with pricePkr < 1500. Prices must match menu data exactly.

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [budget-2] budget

**Prompt:** What can I get for PKR 500?

**Expected:** Should list affordable items (sides, beverages, breads) within the PKR 500 range.

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [budget-3] budget

**Prompt:** What's your most expensive dish?

**Expected:** Should identify the highest-priced item from the menu context.

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [spice-1] spice

**Prompt:** What's your spiciest dish?

**Expected:** Should recommend dishes with spiceLevel 'hot'. Should only use data from the menu.

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [spice-2] spice

**Prompt:** I don't like spicy food, what do you recommend?

**Expected:** Should recommend dishes with spiceLevel 'non-spicy' or 'mild'. Should not suggest 'hot' dishes.

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [spice-3] spice

**Prompt:** Give me something medium spice in desi food

**Expected:** Should filter for cuisineType 'desi' AND spiceLevel 'medium'.

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [pairing-1] pairing

**Prompt:** What goes well with biryani?

**Expected:** Should recommend pairings listed in the biryani menu item's 'pairings' field.

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [pairing-2] pairing

**Prompt:** What drink pairs with the Chicken Karahi?

**Expected:** Should check the pairings field for Chicken Karahi and suggest listed beverages.

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [pairing-3] pairing

**Prompt:** I'm having naan, what main course should I get?

**Expected:** Should suggest main courses that list naan in their pairings or are commonly paired with bread.

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [dietary-1] dietary

**Prompt:** Do you have vegan options?

**Expected:** Should list dishes with dietary 'vegan'. Should not suggest non-vegan dishes.

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [dietary-2] dietary

**Prompt:** What vegetarian dishes do you have?

**Expected:** Should list dishes with dietary 'vegetarian' or 'vegan'. Should not include non-vegetarian items.

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [dietary-3] dietary

**Prompt:** I only eat non-veg. What's your best chicken dish?

**Expected:** Should suggest non-vegetarian chicken dishes. Should mention specialties if relevant.

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [multi-1] multi-person

**Prompt:** What should two people order?

**Expected:** Should suggest a mix of shareable dishes and individual servings. Should consider variety.

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [multi-2] multi-person

**Prompt:** We're a group of 4, suggest a spread

**Expected:** Should recommend a balanced spread with variety across cuisines, including sides and drinks.

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [multi-3] multi-person

**Prompt:** I'm ordering for two, one person likes spicy and the other doesn't

**Expected:** Should suggest one spicy and one mild/non-spicy dish. Should acknowledge both preferences.

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [oom-1] out-of-menu

**Prompt:** Do you have pizza?

**Expected:** Should say pizza is not on the menu. Should suggest a similar alternative from the menu.

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [oom-2] out-of-menu

**Prompt:** Can I get sushi?

**Expected:** Should say sushi is not available. Should suggest a similar alternative (e.g. Chinese or seafood options).

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [order-1] order

**Prompt:** I want 2x Chicken Karahi and 1x Garlic Naan

**Expected:** Should confirm the items and quantities with the diner before calling placeOrder. Should NOT call placeOrder without confirmation.

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [order-2] order

**Prompt:** Place my order

**Expected:** Should ask what the diner wants to order since no items were specified. Should NOT call placeOrder with empty items.

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [order-3] order

**Prompt:** I'll have the Malai Boti, make it extra spicy please

**Expected:** Should confirm the order (1x Malai Boti with note 'extra spicy') and ask for confirmation before placing.

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [cuisine-1] cuisine

**Prompt:** What Chinese dishes do you have?

**Expected:** Should list dishes with cuisineType 'chinese'. Should not include desi or continental items.

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [cuisine-2] cuisine

**Prompt:** Show me your continental menu

**Expected:** Should list dishes with cuisineType 'continental'. Should only mention continental items.

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [specialty-1] specialty

**Prompt:** What are your chef's specialties?

**Expected:** Should recommend dishes with specialty: true. Should highlight what makes them special.

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [multi-criteria-1] multi-criteria

**Prompt:** I want something spicy, dairy-free, and under PKR 600

**Expected:** Should filter for spiceLevel 'hot' or 'medium', no dairy in allergens, and pricePkr < 600. E.g. Schezwan Fried Rice, Seekh Kebab.

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## 💥 [greeting-1] greeting

**Prompt:** Hi, what's on the menu today?

**Expected:** Should greet warmly and provide a brief overview of the menu categories (desi, chinese, continental, fusion, sides/beverages).

**Latency:** N/A

**Response:**
> ERROR: fetch failed

**Issues:**
- 💥 API call failed: fetch failed

---

## Summary Statistics

| Metric | Value |
|--------|-------|
| Total prompts | 30 |
| Passed | 0 |
| Warnings | 0 |
| Failed | 30 |
| Pass rate | 0.0% |
| Avg latency (successful) | 0 ms |
| Min latency | 0 ms |
| Max latency | 0 ms |
| Median latency | 0 ms |
