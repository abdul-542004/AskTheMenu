# AskTheMenu ? Playwright Testing Project

Date: 30 October 2026

## Introduction

This project applies Playwright with Python to test AskTheMenu, a restaurant website. Four main features were selected: chat, menu browsing, the kitchen dashboard and QR table links. Each feature has three end-to-end tests: two positive cases and one negative case. The project also includes four API tests covering CRUD and two network-mocking tests.

Tools used: Python, Playwright, pytest and pytest-html. Tests were run on Chromium, Firefox and WebKit against the local website.

## Features tested and left out

| Feature | Scope | Reason |
| --- | --- | --- |
| Chat assistant | Tested | Main way diners ask questions about the menu. |
| Menu browsing | Tested | Lets diners view dishes, prices and categories. |
| Kitchen dashboard | Tested | Lets staff view orders and change their status. |
| QR table links | Tested | Takes diners to the chat for the correct table. |
| AI answer accuracy and full ordering conversations | Left out | Replies vary, so the chat test checks that a reply arrives and is saved. |
| File/image uploads | Left out | Needs separate upload/storage testing; the four main features were prioritised. |
| Theme and appearance controls | Left out | Lower priority than the main user actions for this assignment. |
| Scanning QR codes with a phone camera | Left out | Tests use desktop browsers to check QR images and table links. |

## Test-case table

Mixed API cases include both successful requests and checks for incorrect input or access.

| ID | Feature | Type | What the test checks | Result |
| --- | --- | --- | --- | --- |
| TC-01 | Chat | Positive | Open the chat page and check the input, send button and model choices. | Pass |
| TC-02 | Chat | Positive | Send a message, receive a reply and check that the conversation remains after refreshing. | Pass |
| TC-03 | Chat | Negative | Try empty and whitespace-only messages; neither should be sent. | Pass |
| TC-04 | Menu | Positive | Open the menu and check its heading, dishes, prices and category links. | Pass |
| TC-05 | Menu | Positive | Click each category and check that its section comes into view. | Pass |
| TC-06 | Menu | Negative | Open a missing menu page; expect HTTP 404 and a not-found message. | Pass |
| TC-07 | Kitchen | Positive | Open the kitchen dashboard and check its heading and filter buttons. | Pass |
| TC-08 | Kitchen | Positive | Check an order's details and move it through accepted, preparing and served. | Pass |
| TC-09 | Kitchen | Negative | Simulate a failed refresh/update; check the error message, unchanged order and Retry button. | Pass |
| TC-10 | QR routing | Positive | Check that all five tables have working QR images and chat links. | Pass |
| TC-11 | QR routing | Positive | Click Table 1 and check that its chat page opens. | Pass |
| TC-12 | QR routing | Negative | Open an invalid table link; check the error message and return to the menu. | Pass |
| TC-13 | API Create | Mixed | POST an order: expect 201 and correct order data. Empty items should return 400. | Pass |
| TC-14 | API Read | Mixed | GET the order list: expect 200 and the created order. A missing API route should return 404. | Pass |
| TC-15 | API Update | Mixed | PATCH an order status: expect 200 and the saved change. Invalid status should return 400. | Pass |
| TC-16 | API Delete | Mixed | DELETE an owned chat: expect 200 and confirm removal. A caller without a session should get 401. | Pass |
| TC-17 | Empty mock | Negative | Mock an empty chat response; check the notification and that another message can be sent. | Pass |
| TC-18 | Error mock | Negative | Mock HTTP 500; check the error notification and that another message can be sent. | Pass |

## API testing and network mocking

The API tests use Playwright's request context to send POST, GET, PATCH and DELETE requests. Create, read and update use orders; delete uses an owned chat. The tests check the response status and returned data, and confirm that changes were saved. They also check invalid input, a missing route and a request without a session.

The two network-mocking tests use page.route() to simulate an empty chat response and an HTTP 500 server error. Each test checks that a message appears, the input remains usable and the user can send another message.

## Test results

There are 18 test cases. The 12 end-to-end tests and two mocking tests run in each of the three browsers, giving 42 browser runs. The four API tests run once, giving 46 runs in total. All 46 passed.

| Browser / test group | Passed | Failed |
| --- | --- | --- |
| Chromium | 14 | 0 |
| Firefox | 14 | 0 |
| WebKit | 14 | 0 |
| API tests (run once) | 4 | 0 |
| Total | 46 | 0 |

## Intentional bug demonstration

To show that a test can catch a website bug, the menu heading was deliberately changed from Restaurant Menu to Unavailable menu. TC-04 still expected Restaurant Menu, so it failed in Chromium, Firefox and WebKit. After the correct heading was restored, the same test passed in all three browsers. The script demonstrate_bug.py repeats this demonstration.

| Bug | What was changed | Test result |
| --- | --- | --- |
| Intentional bug | Menu heading changed from Restaurant Menu to Unavailable menu. | TC-04 failed in all three browsers. After restoring the heading, it passed in all three. |

## Team contributions

| Member | Work |
| --- | --- |
| Member 1: [Name / Student ID] | Chat and menu tests; network mocking tests; bug demonstration and report. |
| Member 2: [Name / Student ID] | Kitchen and QR tests; API tests; screenshots and test reports. |

Both members should be able to explain every test during the final demo. DEMO_GUIDE.md provides a walkthrough for practice.

## Submitted files

The submission ZIP contains the Python test files, an HTML report with all test results, screenshots, the intentional-bug results and this report. The main results are in reports/test_report.html. The bug demonstration is recorded in reports/bug_injected.html and reports/bug_fixed.html. Setup and run instructions are in README.md.
